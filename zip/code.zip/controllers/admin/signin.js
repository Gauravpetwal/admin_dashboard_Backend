const userTable = require("../../models/userModel");
const response = require("../../helpers/response");
const validate = require("../../helpers/validate");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const uuid = require('uuid')
const accessToken = require('../../models/accessToken')
//admin signin
const signin = async (req, res) => {
    const { userEmail, userPassword } = req.body;
    const data = {
      Email: userEmail,
      Password: userPassword,
    };
    const rules = {
      Email: "required|email|isExist:users,email",
      Password: `required`,
    };

    const {status,message} = await validate(data, rules);
    if (!status) return response.failed(res,message, null);
    

    const user = await userTable.findOne({where: { email: userEmail, role: "admin" }});
    if (!user) return response.failed(res, "Invalid Email or Password");

    const confirmPassword = await bcrypt.compare(userPassword, user.Password);
    if (!confirmPassword) return response.failed(res, "Password is incorrect", null);

    const tokenid = uuid.v6()
    const payload = { id: user.id, tokenid}
    const token = jwt.sign(payload, process.env.JWT_SECRET_key, {
      expiresIn: "4h",
    });
    await accessToken.create({tokenid, userid:user.id})
    return response.success(res, message, { token: token });
};

module.exports =signin