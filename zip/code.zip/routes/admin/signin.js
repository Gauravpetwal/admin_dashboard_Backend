const express = require('express')
const router = express.Router()
const signin = require('../../controllers/admin/signin')
const { siginLimiter } = require('../../middlewares/rateLimiting')

router.post('/adminSignin',siginLimiter, signin)

module.exports = router